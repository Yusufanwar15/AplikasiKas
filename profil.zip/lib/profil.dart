import 'package:flutter/material.dart';

class Profil extends StatelessWidget {
  Profil({this.image, this.nama, this.email});

  final image;
  final nama;
  final email;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil'),
        backgroundColor: Colors.teal,
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(20.0),
            child: Center(
              child: Column(
                children: <Widget>[
                  CircleAvatar(
                    backgroundColor: Colors.grey,
                    backgroundImage: AssetImage(image),
                    radius: 70.0,
                  ),
                  Padding(
                    padding: EdgeInsets.all(20.0),
                  ),
                  TextField(
                      decoration: InputDecoration(
                          hintText: nama,
                          hintStyle: TextStyle(color: Colors.black),
                          suffixIcon: Icon(
                            Icons.edit,
                            color: Colors.teal,
                          ))),
                  Padding(
                    padding: EdgeInsets.all(15.0),
                  ),
                  TextField(
                      decoration: InputDecoration(
                          hintText: email,
                          hintStyle: TextStyle(color: Colors.black),
                          suffixIcon: Icon(
                            Icons.edit,
                            color: Colors.teal,
                          ))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
