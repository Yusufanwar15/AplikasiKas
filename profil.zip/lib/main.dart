import 'package:flutter/material.dart';
import 'package:profil/profil.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MenuUtama(),
    ));

class MenuUtama extends StatefulWidget {
  const MenuUtama({Key? key}) : super(key: key);
  _MenuUtamaState createState() => _MenuUtamaState();
}

class _MenuUtamaState extends State<MenuUtama> {
  late String image1 = 'img/login.png';
  late String image2 = 'img/A.png';
  late String gantiGambar;

  late String nama1 = 'Ardeka';
  late String nama2 = 'Figo';
  late String gantiNama;

  late String email1 = 'ArdekaGans@gmail.com';
  late String email2 = 'FigoGans@gmail.com';
  late String gantiEmail;

  void tukar() {
    setState(() {
      gantiGambar = image1;
      image1 = image2;
      image2 = gantiGambar;

      gantiNama = nama1;
      nama1 = nama2;
      nama2 = gantiNama;

      gantiEmail = email1;
      email1 = email2;
      email2 = gantiEmail;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      drawer: Drawer(
          child: ListView(
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text(nama1),
            accountEmail: Text(email1),
            currentAccountPicture: GestureDetector(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => Profil(
                            image: image1,
                            nama: nama1,
                            email: email1,
                          )));
                },
                child: CircleAvatar(
                  backgroundImage: AssetImage(image1),
                  backgroundColor: Colors.white,
                )),
            decoration: BoxDecoration(color: Colors.orange),
            otherAccountsPictures: <Widget>[
              GestureDetector(
                onTap: () => tukar(),
                child: CircleAvatar(
                  backgroundImage: AssetImage(image2),
                  backgroundColor: Colors.white,
                ),
              )
            ],
          ),
          ListTile(
            leading: Icon(Icons.calendar_today),
            title: Text(
              "Calender",
              style: TextStyle(color: Colors.black),
            ),
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text(
              "Setting",
              style: TextStyle(color: Colors.black),
            ),
          ),
          ListTile(
            leading: Icon(Icons.close),
            title: Text(
              "Close",
              style: TextStyle(color: Colors.black),
            ),
          ),
        ],
      )),
      body: Container(
          child: Center(
        child: Text("BukuKas"),
      )),
    );
  }
}
